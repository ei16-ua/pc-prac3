use crate::venue::Venue;
use std::thread;

use crate::booking::{Booker, ConcurrentBooker, SequentialBooker};
use crate::simulation::simulate_booking;

/// Trait que define las operaciones del gestor de colas.
pub trait QueueManager {
    fn new(venue: Venue) -> Self;
    fn run(&mut self) -> Vec<String>;
    fn get_venue(&self) -> Venue;
}

/// Implementación secuencial de referencia.
pub struct SequentialQueueManager {
    booker: SequentialBooker,
}

impl QueueManager for SequentialQueueManager {
    fn new(venue: Venue) -> Self {
        SequentialQueueManager {
            booker: SequentialBooker::new(venue),
        }
    }

    fn run(&mut self) -> Vec<String> {
        let mut sold_tickets = Vec::with_capacity(self.booker.get_total_capacity());
        while self.booker.remaining_seats() > 0 {
            let tickets = simulate_booking(&mut self.booker);
            sold_tickets.extend(tickets);

            println!(
                "Venue: {} Remaining seats: {}",
                self.booker.get_venue_name(),
                self.booker.remaining_seats()
            );
        }
        sold_tickets
    }

    fn get_venue(&self) -> Venue {
        self.booker.get_venue()
    }
}

/// Hilos compradores por núcleo. La simulación es casi todo esperas
/// (`sleep`), así que compensa lanzar muchos más hilos que núcleos.
const THREADS_PER_CORE: usize = 128;

/// Decide cuántos hilos lanzar según los núcleos de la máquina y el aforo.
fn n_threads(capacity: usize) -> usize {
    let cores = thread::available_parallelism().map(|n| n.get()).unwrap_or(4);
    (cores * THREADS_PER_CORE)
        .clamp(64, 2048)
        .min(capacity.max(1)) // no tiene sentido lanzar más hilos que entradas
}

/// Implementación concurrente: un grupo de hilos que atienden sesiones de
/// compra en paralelo hasta agotar el aforo.
pub struct ConcurrentQueueManager {
    booker: ConcurrentBooker,
}

impl QueueManager for ConcurrentQueueManager {
    fn new(venue: Venue) -> Self {
        ConcurrentQueueManager {
            booker: ConcurrentBooker::new(venue),
        }
    }

    fn run(&mut self) -> Vec<String> {
        let mut sold_tickets = Vec::with_capacity(self.booker.get_total_capacity());

        // `thread::scope` garantiza que todos los hilos han terminado al salir.
        thread::scope(|scope| {
            let workers: Vec<_> = (0..n_threads(self.booker.get_total_capacity()))
                .map(|_| {
                    // Cada hilo recibe su propio clon del booker (comparten el Arc).
                    let mut booker = self.booker.clone();
                    scope.spawn(move || {
                        // Tickets vendidos por este hilo: Vec local, sin cerrojo.
                        let mut mis_tickets = Vec::new();
                        while booker.remaining_seats() > 0 {
                            let tickets = simulate_booking(&mut booker);
                            if tickets.is_empty() {
                                // Sesión sin compra (p. ej. todo lo que queda
                                // está seleccionado por otros): ceder la CPU.
                                thread::yield_now();
                            } else {
                                mis_tickets.extend(tickets);
                            }
                        }
                        mis_tickets
                    })
                })
                .collect();

            // Recolección: cada hilo devuelve su Vec al hacer join.
            for worker in workers {
                sold_tickets.extend(worker.join().expect("un hilo comprador ha fallado"));
            }
        });

        sold_tickets
    }

    fn get_venue(&self) -> Venue {
        self.booker.get_venue()
    }
}
