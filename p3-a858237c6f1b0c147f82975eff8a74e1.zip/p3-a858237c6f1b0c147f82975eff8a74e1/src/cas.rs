use std::sync::atomic::Ordering;

use crate::venue::SectorNumerado;

/// Intenta cambiar todas las butacas de un estado a otro con CAS.
///
/// Si una butaca falla, revierte las anteriores y devuelve su índice.
pub(crate) fn cambiar_todas(
    sector: &SectorNumerado,
    idxs: &[usize],
    desde: u8,
    hasta: u8,
) -> Result<(), usize> {
    for (k, &i) in idxs.iter().enumerate() {
        if sector.seats[i]
            .compare_exchange(desde, hasta, Ordering::AcqRel, Ordering::Acquire)
            .is_err()
        {
            for &j in &idxs[..k] {
                sector.seats[j].store(desde, Ordering::Release);
            }
            return Err(i);
        }
    }
    Ok(())
}
