use crate::venue::Venue;
use crate::booking::{SequentialBooker, Booker};
use crate::simulation::simulate_booking;

/// Trait que define las operaciones del gestor de colas.
pub trait QueueManager {
    fn new(venue: Venue) -> Self;
    fn run(&mut self) -> Vec<String>;
    fn get_venue(&self) -> Venue;
}

/// Implementación secuencial de referencia.
pub struct SequentialQueueManager {
    booker: SequentialBooker,
}

impl QueueManager for SequentialQueueManager {
    fn new(venue: Venue) -> Self {
        SequentialQueueManager {
            booker: SequentialBooker::new(venue),
        }
    }

    fn run(&mut self) -> Vec<String> {
        let mut sold_tickets = Vec::with_capacity(self.booker.get_total_capacity());
        while self.booker.remaining_seats() > 0 {
            let tickets = simulate_booking(&mut self.booker);
            sold_tickets.extend(tickets);

            println!(
                "Venue: {} Remaining seats: {}",
                self.booker.get_venue_name(),
                self.booker.remaining_seats()
            );
        }
        sold_tickets
    }

    fn get_venue(&self) -> Venue {
        self.booker.get_venue()
    }
}

/// Implementación concurrente que deben completar los alumnos.
pub struct ConcurrentQueueManager {
    // TODO: Diseñar la estructura de cola concurrente (hilos workers, etc.)
}

impl QueueManager for ConcurrentQueueManager {
    fn new(_venue: Venue) -> Self {
        // TODO: Implementar
        ConcurrentQueueManager {}
    }

    fn run(&mut self) -> Vec<String> {
        // TODO: Implementar la orquestación concurrente y recolección de tickets
        Vec::new()
    }

    fn get_venue(&self) -> Venue {
        // TODO: Implementar
        Venue {
            name: String::new(),
            sectors: vec![],
        }
    }
}