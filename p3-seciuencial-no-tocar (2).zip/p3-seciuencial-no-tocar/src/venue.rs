use std::fmt;

/// Modelo de un recinto (*Venue*), compuesto por un nombre y múltiples sectores.
#[derive(Clone)]
pub struct Venue {
    pub name: String,
    pub sectors: Vec<Sector>,
}

impl Venue {
    /// Capacidad total sumando todos los sectores.
    pub fn total_capacity(&self) -> usize {
        self.sectors.iter().map(|s| s.capacity).sum()
    }

    /// Total de asientos disponibles sumando todos los sectores.
    pub fn total_available_seats(&self) -> usize {
        self.sectors.iter().map(|s| s.n_available_seats()).sum()
    }

    /// Total de asientos ya vendidos (*Booked*) sumando todos los sectores.
    pub fn total_booked_seats(&self) -> usize {
        self.sectors.iter().map(|s| s.n_booked_seats()).sum()
    }
}

impl fmt::Display for Venue {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{} {}/{}\n",
            self.name,
            self.total_booked_seats(),
            self.total_capacity(),
        )?;

        write!(f, "Sectors:\n")?;

        for sector in &self.sectors {
            write!(
                f,
                "  - {} ({}) {}/{}\n",
                sector.name,
                sector.code,
                sector.n_booked_seats(),
                sector.capacity,
            )?;
        }
        Ok(())
    }
}

/// Representa un sector dentro del recinto.
///
/// Cada sector tiene un nombre descriptivo, un código corto (p. ej. `"ST"`, `"S1"`),
/// un vector de asientos (`Seat`), una capacidad total y una bandera que indica
/// si los asientos son numerados (`is_numbered: true`) o de admisión general (`false`).
#[derive(Clone)]
pub struct Sector {
    pub name: String,
    pub code: String,
    pub seats: Vec<Seat>,
    pub capacity: usize,
    pub is_numbered: bool,
}

/// Estado en el que se encuentra un asiento o localidad.
#[derive(PartialEq, Clone)]
pub enum SeatState {
    /// Asiento libre, disponible para selección.
    Available,
    /// Asiento bloqueado provisionalmente por una sesión de compra.
    Selected,
    /// Asiento vendido definitivamente.
    Booked,
}

/// Representa una localidad individual con su estado e identificador único.
#[derive(Clone)]
pub struct Seat {
    pub state: SeatState,
    pub id: String,
}

impl Sector {
    /// Crea un nuevo sector inicializando todos sus asientos en estado `Available`.
    pub fn new(name: &str, code: &str, capacity: usize, is_numbered: bool) -> Sector {
        let seats = (1..=capacity)
            .map(|i| Seat {
                state: SeatState::Available,
                id: format!("{}-{}", code, i),
            })
            .collect();

        Sector {
            name: name.to_string(),
            code: code.to_string(),
            seats,
            capacity,
            is_numbered,
        }
    }

    /// Devuelve referencias a todos los asientos que se encuentran actualmente disponibles.
    pub fn get_available_seats(&self) -> Vec<&Seat> {
        self.seats.iter().filter(|s| s.state == SeatState::Available).collect()
    }

    /// Devuelve el número de asientos actualmente en estado `Available`.
    pub fn n_available_seats(&self) -> usize {
        self.seats.iter().filter(|s| s.state == SeatState::Available).count()
    }

    /// Devuelve el número de asientos actualmente en estado `Booked`.
    pub fn n_booked_seats(&self) -> usize {
        self.seats.iter().filter(|s| s.state == SeatState::Booked).count()
    }
}
